#include <stdio.h>
#include <stdlib.h>
#define TAM 5
int main() {
  int opcao[TAM], cont = 0;
  float percent[TAM];
  char codigo;
  printf("╔══─══─══─══─⊱☪ ⊰─══─══─══─══╗\n");
  printf("☾   Pesquisa de Satisfação   ☽\n");
  printf("╚══─══─══─══─⊱☪ ⊰─══─══─══─══╝\n");
  do {
  printf("╔════════╦═════════════════╗\n");
  printf("║ Código ║ Grau Satisfação ║\n");
  printf("║ ➢  𝑒   ║ ➢ Satisfeito    ║\n");
  printf("║ ➢  𝒸   ║ ➢ Contente      ║\n");
  printf("║ ➢  𝓂   ║ ➢ Meia-boca     ║\n");
  printf("║ ➢  𝓊   ║ ➢ Uma droga     ║\n");
  printf("║ ➢  𝓃   ║ ➢ Voto nulo     ║\n");
  printf("╚════════╩═════════════════╝\n");

  printf("╔══─══──══─⊱ ☪ ⊰─══─══─══╗\n");
  printf("☾ Vote usando os códigos ☽\n");
  printf("╚══─══──══─⊱ ☪ ⊰─══─══─══╝\n");

  
    printf(" 👉 ");
    scanf("%c", &codigo);
    system ("clear");
    getchar();
    switch (codigo) {
    case 'e':
    case 'E': {
      opcao[0]++;
      cont++;
      system ("clear");
    } break;
    case 'c':
    case 'C': {
      opcao[1]++;
      cont++;
      system ("clear");
    } break;
    case 'm':
    case 'M': {
      opcao[2]++;
      cont++;
      system ("clear");
    } break;
    case 'u':
    case 'U': {
      opcao[3]++;
      cont++;
      system ("clear");
    } break;
    case 'n':
    case 'N': {
      opcao[4]++;
      cont++;
      system ("clear");
      
    } break;
    default: {
      system ("clear");
      printf("┌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┐\n");
      printf("│ Código inválido / Digite outro │\n");
      printf("└╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┘\n");
    }
    }
  } while (cont != 5);

  // calculo do percentual
  for (cont = 0; cont < TAM; cont++) {
    percent[cont] = (float)opcao[cont] / 5 * 100;
  }

  printf("\n╔══─══─⊱ ☪ ⊰─══─══╗\n");
  printf("☾   Resultados:   ☽\n");
  printf("╚══─══─⊱ ☪ ⊰─══─══╝\n");

  printf("╔═════════════════╦═══════╦════════════╗\n");
  printf("║ Grau Satisfação ║ Votos ║ Percentual ║\n");
  if (opcao[0] > 9) {
    printf("║ ➢ Satisfeito    ║ ➢  %i ║   %%%.2f   ║\n", opcao[0], percent[0]);
  } else {
    printf("║ ➢ Satisfeito    ║ ➢  0%i ║   %%%.2f   ║\n", opcao[0], percent[0]);
  }
  if (opcao[1] > 9) {
    printf("║ ➢ Contente      ║ ➢  %i ║   %%%.2f   ║\n", opcao[1], percent[1]);
  } else {
    printf("║ ➢ Contente      ║ ➢  0%i ║   %%%.2f   ║\n", opcao[1], percent[1]);
  }
  if (opcao[2] > 9) {
    printf("║ ➢ Meia-boca     ║ ➢  %i ║   %%%.2f   ║\n", opcao[2], percent[2]);
  } else {
    printf("║ ➢ Meia-boca     ║ ➢  0%i ║   %%%.2f   ║\n", opcao[2], percent[2]);
  }
  if (opcao[3] > 9) {
    printf("║ ➢ Uma droga     ║ ➢  %i ║   %%%.2f   ║\n", opcao[3], percent[3]);
  } else {
    printf("║ ➢ Uma droga     ║ ➢  0%i ║   %%%.2f   ║\n", opcao[3], percent[3]);
  }
  if (opcao[4] > 9) {
    printf("║ ➢ Voto nulo     ║ ➢  %i ║   %%%.2f   ║\n", opcao[4], percent[4]);
  } else {
    printf("║ ➢ Voto nulo     ║ ➢  0%i ║   %%%.2f   ║\n", opcao[4], percent[4]);
  }
  printf("╚═════════════════╩═══════╩════════════╝\n");
  printf("╔══─══─⊱ ☪ ⊰─══─══╗\n");
  printf("☾ Finalizando...  ☽\n");
  printf("╚══─══─⊱ ☪ ⊰─══─══╝\n");
}