#include <stdio.h>
#include <stdlib.h>
#define TAM 5
int main() {
  int codigo, candidato[TAM], votos, maior, cont, cont2, teste, teste2;
  do {
    do {
      do {
        maior = -1;
        teste2 = 0;
        teste = 0;
        candidato[0] = 0;
        candidato[1] = 0;
        candidato[2] = 0;
        candidato[3] = 0;
        candidato[4] = 0;
        printf("            ╔════════╗\n");
        printf("            ║ Tabela ║\n");
        printf("╔════════╦══╩════════╩══╦════════╗\n");
        printf("║ CÓDIGO ║  CANDIDATO   ║  VOTO  ║\n");
        printf("╠════════╬══════════════╬════════╣\n");
        printf("║   01   ║  Seu Pedro   ║   00   ║\n");
        printf("║   02   ║  Dona Maria  ║   00   ║\n");
        printf("║   03   ║  Tia Daina   ║   00   ║\n");
        printf("║   04   ║  Seu Antônio ║   00   ║\n");
        printf("║   05   ║  VOTO NULO   ║   00   ║\n");
        printf("╠════════╬══════════════╩════════╣\n");
        printf("║   00   ║    Para Finalizar     ║\n");
        printf("╚════════╩═══════════════════════╝\n");
        printf(" ╔══════════════════════════════╗\n");
        printf(" ║ Digite o código do candidato ║\n");
        printf(" ╚══════════════════════════════╝\n");
        do {
          printf("              👉 ");
          scanf("%i", &codigo);
          switch (codigo) {
          case 0: {
          } break;
          case 1: {
            candidato[0]++;
          } break;
          case 2: {
            candidato[1]++;
          } break;
          case 3: {
            candidato[2]++;
          } break;
          case 4: {
            candidato[3]++;
          } break;
          case 5: {
            candidato[4]++;
          } break;
          default: {
            printf("┌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┐\n");
            printf("│ Código inválido / Digite outro │\n");
            printf("└╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┘\n");
          }
          }
        } while (codigo != 0);
        printf("\n");
        printf("    ╔═══════════════╗\n");
        printf("    ║ Tabela Final: ║\n");
        printf("╔═══╩══════════╦════╩═══╗\n");
        printf("║  CANDIDATO   ║  VOTO  ║\n");
        printf("╠══════════════╬════════╣\n");
        if (candidato[0] > 9) {
          printf("║  Seu Pedro   ║   %i   ║\n", candidato[0]);
        } else {
          printf("║  Seu Pedro   ║   0%i   ║\n", candidato[0]);
        }
        if (candidato[1] > 9) {
          printf("║  Dona Maria  ║   %i   ║\n", candidato[1]);
        } else {
          printf("║  Dona Maria  ║   0%i   ║\n", candidato[1]);
        }
        if (candidato[2] > 9) {
          printf("║  Tia Daina   ║   %i   ║\n", candidato[2]);
        } else {
          printf("║  Tia Daina   ║   0%i   ║\n", candidato[2]);
        }
        if (candidato[3] > 9) {
          printf("║  Seu Antônio ║   %i   ║\n", candidato[3]);
        } else {
          printf("║  Seu Antônio ║   0%i   ║\n", candidato[3]);
        }
        if (candidato[4] > 9) {
          printf("║  VOTO NULO   ║   %i   ║\n", candidato[4]);
        } else {
          printf("║  VOTO NULO   ║   0%i   ║\n", candidato[4]);
        }
        printf("╚══════════════╩════════╝\n");

        // para saber quem teve a maior quantidade de votos.
        for (cont = 0; cont < TAM; cont++) {
          for (cont2 = 0; cont2 < TAM; cont2++) {
            if (candidato[cont] > candidato[cont2] && candidato[cont] > maior) {
              maior = candidato[cont];
            }
          }
        }

        // se todos os candidatos receberam a mesma quantidade de votos.
        for (cont = 0; cont < TAM; cont++) {
          if (maior < candidato[cont]) {
            teste2++;
          } else {
            break;
          }
        }
        if (teste2 == TAM) {
          printf("┌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┐\n");
          printf("│ Empate entre candidatos, devemos refazer a votação! │\n");
          printf("└╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┘\n");
          getchar();
        }
        getchar();
      } while (teste2 == TAM);

      // para saber se ocorreu um empate.
      for (cont = 0; cont < TAM; cont++) {
        if (maior == candidato[cont]) {
          teste++;
        }
      }
      if (teste > 1) {
        printf("┌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┐\n");
        printf("│ Empate entre candidatos, devemos refazer a votação! │\n");
        printf("└╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┘\n");
        getchar();
      }
    } while (teste > 1);
    // para saber quem foi o vencedor.
    if (maior == candidato[0]) {
      printf("╔════════════════════════════════════════════╗\n");
      printf("║ * O vencedor foi o Seu Pedro com %i votos * ║\n", maior);
      printf("╠════════╦═══════════════════════════════════╝\n");
    } else if (maior == candidato[1]) {
      printf("╔══════════════════════════════════════════════╗\n");
      printf("║ * A vencedora foi a Dona Maria com %i votos * ║\n", maior);
      printf("╠════════╦═════════════════════════════════════╝\n");
    } else if (maior == candidato[2]) {
      printf("╔═════════════════════════════════════════════╗\n");
      printf("║ * A vencedora foi a Tia Daina com %i votos * ║\n", maior);
      printf("╠════════╦════════════════════════════════════╝\n");
    } else if (maior == candidato[3]) {
      printf("╔══════════════════════════════════════════════╗\n");
      printf("║ * O vencedor foi o Seu Antônio com %i votos * ║\n", maior);
      printf("╠════════╦═════════════════════════════════════╝\n");
    } else if (maior == candidato[4]) {
      printf("┌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┐\n");
      printf("│ Os votos nulos ganharam, devemos refazer a votação! │\n");
      printf("└╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┘\n");
      getchar();
    }
  } while (maior == candidato[4]);

  printf("║ Fim... ║\n");
  printf("╚════════╝\n");
}