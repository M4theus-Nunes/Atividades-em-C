#include <stdio.h>
#include <stdlib.h>
#define TAM 5
int main() {
  int codigo, candidato[TAM], votos, maior, cont, cont2, teste, teste2;
  do {
    do {
      do {
        maior = -1;
        teste2 = 0;
        teste = 0;
        candidato[0] = 0;
        candidato[1] = 0;
        candidato[2] = 0;
        candidato[3] = 0;
        candidato[4] = 0;
        do {
          printf("╔════════╦══════════════╗\n");
          printf("║ Código ║  CANDIDATO   ║\n");
          printf("╠════════╬══════════════╣\n");
          printf("║   01   ║  Seu Pedro   ║\n");
          printf("║   02   ║  Dona Maria  ║\n");
          printf("║   03   ║  Tia Daina   ║\n");
          printf("║   04   ║  Seu Antônio ║\n");
          printf("║   05   ║  VOTO NULO   ║\n");
          printf("╠════════╬══════════════╣\n");
          printf("║   00   ║     Sair     ║\n");
          printf("╚════════╩══════════════╝\n");
          printf("╔══════════════════════════════╗\n");
          printf("║ Digite o código do candidato ║\n");
          printf("╚══════════════════════════════╝\n");
          printf("              👉 ");
          scanf("%i", &codigo);
          switch (codigo) {
          case 0: {
            system("clear");
          } break;
          case 1: {
            candidato[0]++;
            printf("╔═══════════════════════════════╗\n");
            printf("║ Voto computado para Seu pedro ║\n");
            printf("╠══════════════════════╦════════╝\n");
            printf("║ Enter para confirmar ║\n");
            printf("╚══════════════════════╝\n");
            getchar();
            getchar();
            system("clear");
          } break;
          case 2: {
            candidato[1]++;
            printf("╔════════════════════════════════╗\n");
            printf("║ Voto computado para Dona Maria ║\n");
            printf("╠══════════════════════╦═════════╝\n");
            printf("║ Enter para confirmar ║\n");
            printf("╚══════════════════════╝\n");
            getchar();
            getchar();
            system("clear");
          } break;
          case 3: {
            candidato[2]++;
            printf("╔═══════════════════════════════╗\n");
            printf("║ Voto computado para Tia Daina ║\n");
            printf("╠══════════════════════╦════════╝\n");
            printf("║ Enter para confirmar ║\n");
            printf("╚══════════════════════╝\n");
            getchar();
            getchar();
            system("clear");
          } break;
          case 4: {
            candidato[3]++;
            printf("╔═════════════════════════════════╗\n");
            printf("║ Voto computado para Seu Antônio ║\n");
            printf("╠══════════════════════╦══════════╝\n");
            printf("║ Enter para confirmar ║\n");
            printf("╚══════════════════════╝\n");
            getchar();
            getchar();
            system("clear");
          } break;
          case 5: {
            candidato[4]++;
            printf("╔═══════════╗\n");
            printf("║ Voto Nulo ║\n");
            printf("╠═══════════╩══════════╗\n");
            printf("║ Enter para confirmar ║\n");
            printf("╚══════════════════════╝\n");
            getchar();
            getchar();
            system("clear");
          } break;
          default: {
            system("clear");
            printf("┌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┐\n");
            printf("│ Código inválido / Digite outro │\n");
            printf("└╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┘\n");
          }
          }
        } while (codigo != 0);
        printf("\n");
        printf("    ╔═══════════════╗\n");
        printf("    ║ Tabela Final: ║\n");
        printf("╔═══╩══════════╦════╩═══╗\n");
        printf("║  CANDIDATO   ║  VOTO  ║\n");
        printf("╠══════════════╬════════╣\n");
        if (candidato[0] > 9) {
          printf("║  Seu Pedro   ║   %i   ║\n", candidato[0]);
        } else {
          printf("║  Seu Pedro   ║   0%i   ║\n", candidato[0]);
        }
        if (candidato[1] > 9) {
          printf("║  Dona Maria  ║   %i   ║\n", candidato[1]);
        } else {
          printf("║  Dona Maria  ║   0%i   ║\n", candidato[1]);
        }
        if (candidato[2] > 9) {
          printf("║  Tia Daina   ║   %i   ║\n", candidato[2]);
        } else {
          printf("║  Tia Daina   ║   0%i   ║\n", candidato[2]);
        }
        if (candidato[3] > 9) {
          printf("║  Seu Antônio ║   %i   ║\n", candidato[3]);
        } else {
          printf("║  Seu Antônio ║   0%i   ║\n", candidato[3]);
        }
        if (candidato[4] > 9) {
          printf("║  VOTO NULO   ║   %i   ║\n", candidato[4]);
        } else {
          printf("║  VOTO NULO   ║   0%i   ║\n", candidato[4]);
        }
        printf("╚══════════════╩════════╝\n");

        // para saber quem teve a maior quantidade de votos.
        for (cont = 0; cont < 4; cont++) {
          for (cont2 = 0; cont2 < 4; cont2++) {
            if (candidato[cont] > candidato[cont2] && candidato[cont] > maior) {
              maior = candidato[cont];
            }
          }
        }

        // se todos os candidatos receberam a mesma quantidade de votos.
        for (cont = 0; cont < 4; cont++) {
          if (maior < candidato[cont]) {
            teste2++;
          } else {
            break;
          }
        }
        if (teste2 == 4) {
          printf("┌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┐"
                 "\n");
          printf("│ Empate entre todos candidatos, devemos refazer a votação! "
                 "│\n");
          printf("└╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┘"
                 "\n");
          printf("╔════════════════════╗\n");
          printf("║ Enter para refazer ║\n");
          printf("╚════════════════════╝\n");
          getchar();
          getchar();
          system("clear");
        }
      } while (teste2 == 4);

      // para saber se ocorreu um empate.
      for (cont = 0; cont < 4; cont++) {
        if (maior == candidato[cont]) {
          teste++;
        }
      }
      if (teste > 1) {
        printf("┌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┐\n");
        printf("│ Empate entre candidatos, devemos refazer a votação! │\n");
        printf("└╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┘\n");
        printf("╔════════════════════╗\n");
        printf("║ Enter para refazer ║\n");
        printf("╚════════════════════╝\n");
        getchar();
        getchar();
        system("clear");
      }
    } while (teste > 1);

    // para saber quem foi o vencedor.
    if (maior == candidato[0]) {
      printf("╔════════════════════════════════════════════╗\n");
      printf("║ * O vencedor foi o Seu Pedro com %i votos * ║\n", maior);
      printf("╠════════╦═══════════════════════════════════╝\n");
    } else if (maior == candidato[1]) {
      printf("╔══════════════════════════════════════════════╗\n");
      printf("║ * A vencedora foi a Dona Maria com %i votos * ║\n", maior);
      printf("╠════════╦═════════════════════════════════════╝\n");
    } else if (maior == candidato[2]) {
      printf("╔═════════════════════════════════════════════╗\n");
      printf("║ * A vencedora foi a Tia Daina com %i votos * ║\n", maior);
      printf("╠════════╦════════════════════════════════════╝\n");
    } else if (maior == candidato[3]) {
      printf("╔══════════════════════════════════════════════╗\n");
      printf("║ * O vencedor foi o Seu Antônio com %i votos * ║\n", maior);
      printf("╠════════╦═════════════════════════════════════╝\n");
    }
  } while (maior == candidato[4]);
  printf("║ Fim... ║\n");
  printf("╚════════╝\n");
}