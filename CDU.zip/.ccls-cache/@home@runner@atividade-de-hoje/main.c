#include <stdio.h>
main () {
int dezena, centena, unidade, resto, numero;
  do{
  printf ("Digite um numero entre 0-999: ");
  scanf ("%i", &numero);
  } while (numero < 0 || numero >999);
  centena = numero / 100;
  resto = numero % 100;
 dezena = resto / 10;
  unidade = resto % 10;
  printf ("\nCentena: %i\n", centena);
  printf ("Dezena: %i\n", dezena);
  printf ("Unidade: %i\n", unidade);
}