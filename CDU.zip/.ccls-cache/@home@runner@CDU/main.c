#include <stdio.h>
#include <string.h>
#include "EXTENSO.h"

//começo do programa
int main() {
  int numero, centena = 0, milhao = 0, milhar = 0, ver = 0, gen, tipo;
  char ext[1000];
  strcpy(ext, "");

  do {
    printf("Digite um numero entre 0-1B: ");
    scanf("%i", &numero);
  } while (numero < 0 || numero > 999999999);

  do {
    printf("Digite um genero, (0-masc) ou (1-fem): ");
    scanf("%i", &gen);
  } while (gen < 0 || gen > 1);

  do {
    printf("Digite um tipo, (0-card) ou (1-ord): ");
    scanf("%i", &tipo);
  } while (tipo < 0 || tipo > 1);

  INTER(numero, &ext[0], gen, tipo);
  printf("\n%s", ext);
}
