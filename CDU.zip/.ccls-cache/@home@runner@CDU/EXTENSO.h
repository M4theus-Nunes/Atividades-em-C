#include <stdio.h>
#include <string.h>
// protótipos
void CARD_M(int numero, char *ext, int ver);
void CARD_F(int numero, char *ext, int ver);

void ORD_M(int numero, char *ext, int ver);
void ORD_F(int numero, char *ext, int ver);

void INTER(int numero, char *ext, int gen, int tipo);

// funções
void INTER(int numero, char *ext, int gen, int tipo) {
  int milhao = 0, milhar = 0, centena = 0, ver;

  if (numero == 0) {
    strcpy(ext, "Zero");

    printf("milhao: %i\n", milhao);
    printf("milhar: %i\n", milhar);
    printf("unidades: %i\n", centena);
  } else {

    milhao = (int)numero / 1000000;
    numero = (int)numero % 1000000;
    milhar = (int)numero / 1000;
    numero = (int)numero % 1000;
    centena = (int)numero;

    printf("milhao: %i\n", milhao);
    printf("milhar: %i\n", milhar);
    printf("unidades: %i\n", centena);

    if (tipo == 0) {

      if (gen == 0) {

        if (milhao != 0) {
          ver = 1;
          CARD_M(milhao, &ext[0], ver);
          if (milhar == 0 && centena > 0 && centena < 101)
            strcat(ext, "e ");
        }

        if (milhar != 0) {
          ver = 2;
          CARD_M(milhar, &ext[0], ver);
          if (centena > 0 && centena < 101)
            strcat(ext, "e ");
        }

        if (centena != 0) {
          ver = 3;
          CARD_M(centena, &ext[0], ver);
        }
      } else {

        if (milhao > 0) {
          ver = 1;
          CARD_F(milhao, &ext[0], ver);
          if (milhar == 0 && centena > 0 && centena < 101)
            strcat(ext, "e ");
        }
        if (milhar > 0) {
          ver = 2;
          CARD_F(milhar, &ext[0], ver);
          if (centena > 0 && centena < 101)
            strcat(ext, "e ");
        }
        if (centena != 0) {
          ver = 3;
          CARD_F(centena, &ext[0], ver);
        }
      }

    } else {

      if (gen == 0) {

        if (milhao > 0)
          ver = 1;
        ORD_M(milhao, &ext[0], ver);
        if (milhar > 0)
          ver = 2;
        ORD_M(milhar, &ext[0], ver);
        ver = 3;
        if (centena != 0)
          ver = 3;
        ORD_M(centena, &ext[0], ver);
      } else {

        if (milhao > 0)
          ver = 1;
        ORD_F(milhao, &ext[0], ver);
        if (milhar > 0)
          ver = 2;
        ORD_F(milhar, &ext[0], ver);
        ver = 3;
        if (centena > 0)
          ver = 3;
        ORD_F(centena, &ext[0], ver);
      }
    }
  }
}

void CARD_M(int numero, char *ext, int ver) {
  int centena = 0, dezena = 0, unidade = 0;
  char c[1000], d[1000], u[1000], txt[1000];

  strcpy(c, "");
  strcpy(d, "");
  strcpy(u, "");

  centena = (int)numero / 100;
  numero = (int)numero % 100;
  dezena = (int)numero / 10;
  unidade = (int)numero % 10;

  switch (centena) {
  case 1: {
    if (dezena > 0 || unidade > 0) {
      strcpy(c, "cento");
    } else {
      strcpy(c, "cem");
    }
  } break;
  case 2: {
    strcpy(c, "duzentos");
  } break;
  case 3: {
    strcpy(c, "trezentos");
  } break;
  case 4: {
    strcpy(c, "quatrocentos");
  } break;
  case 5: {
    strcpy(c, "quinhentos");
  } break;
  case 6: {
    strcpy(c, "seiscentos");
  } break;
  case 7: {
    strcpy(c, "setecentos");
  } break;
  case 8: {
    strcpy(c, "oitocentos");
  } break;
  case 9: {
    strcpy(c, "novecentos");
  }
  }

  switch (dezena) {
  case 1: {
    if (unidade == 0) {
      strcpy(d, "dez");
    } else {
      switch (unidade) {
      case 1: {
        strcpy(d, "onze");
      } break;
      case 2: {
        strcpy(d, "doze");
      } break;
      case 3: {
        strcpy(d, "treze");
      } break;
      case 4: {
        strcpy(d, "catorze");
      } break;
      case 5: {
        strcpy(d, "quince");
      } break;
      case 6: {
        strcpy(d, "dezesseis");
      } break;
      case 7: {
        strcpy(d, "dezessete");
      } break;
      case 8: {
        strcpy(d, "dezoito");
      } break;
      case 9: {
        strcpy(d, "dezenove");
      } break;
      }
    }
  } break;
  case 2: {
    strcpy(d, "vinte");
  } break;
  case 3: {
    strcpy(d, "trinta");
  } break;
  case 4: {
    strcpy(d, "quarenta");
  } break;
  case 5: {
    strcpy(d, "cinquenta");
  } break;
  case 6: {
    strcpy(d, "sessenta");
  } break;
  case 7: {
    strcpy(d, "setenta");
  } break;
  case 8: {
    strcpy(d, "oitenta");
  } break;
  case 9: {
    strcpy(d, "noventa");
  }
  }

  if (dezena != 1)
    switch (unidade) {
    case 1: {
      if (ver == 2 && dezena > 1 || centena > 0)
        strcpy(u, "um");
      if (ver != 2) {
        strcpy(u, "um");
      }
    } break;
    case 2: {
      strcpy(u, "dois");
    } break;
    case 3: {
      strcpy(u, "três");
    } break;
    case 4: {
      strcpy(u, "quatro");
    } break;
    case 5: {
      strcpy(u, "cinco");
    } break;
    case 6: {
      strcpy(u, "seis");
    } break;
    case 7: {
      strcpy(u, "sete");
    } break;
    case 8: {
      strcpy(u, "oito");
    } break;
    case 9: {
      strcpy(u, "nove");
    }
    }

  // verificar se tem e

  if (centena != 0) {
    if (dezena > 0 || unidade > 0) {
      strcat(c, " e ");
    }
  }

  if (dezena != 1) {
    if (unidade > 0 && dezena > 1) {
      strcat(d, " e ");
    }
  }

  // verificar milhao e mil
  if (ver == 1) {
    if (centena == 0 && dezena == 0 && unidade == 1)
      strcat(u, " milhão ");
    if (centena > 0 || dezena > 0 || unidade > 1)
      strcat(u, " milhões ");
  }

  if (ver == 2) {
    if (numero == 1) {
      strcat(u, "mil ");
    } else {
      strcat(u, " mil ");
    }
  }

  strcpy(txt, "");
  strcat(txt, c);
  strcat(txt, d);
  strcat(txt, u);
  strcat(ext, txt);
}

void CARD_F(int numero, char *ext, int ver) {
  int centena = 0, dezena = 0, unidade = 0;
  char c[1000], d[1000], u[1000], txt[1000];

  strcpy(c, "");
  strcpy(d, "");
  strcpy(u, "");

  centena = (int)numero / 100;
  numero = (int)numero % 100;
  dezena = (int)numero / 10;
  unidade = (int)numero % 10;

  switch (centena) {
  case 1: {
    if (dezena > 0 || unidade > 0) {
      strcpy(c, "cento");
    } else {
      strcpy(c, "cem");
    }
  } break;
  case 2: {
    strcpy(c, "duzentas");
  } break;
  case 3: {
    strcpy(c, "trezentas");
  } break;
  case 4: {
    strcpy(c, "quatrocentas");
  } break;
  case 5: {
    strcpy(c, "quinhentas");
  } break;
  case 6: {
    strcpy(c, "seiscentas");
  } break;
  case 7: {
    strcpy(c, "setecentas");
  } break;
  case 8: {
    strcpy(c, "oitocentas");
  } break;
  case 9: {
    strcpy(c, "novecentas");
  }
  }

  switch (dezena) {
  case 1: {
    if (unidade == 0) {
      strcpy(d, "dez");
    } else {
      switch (unidade) {
      case 1: {
        strcpy(d, "onze");
      } break;
      case 2: {
        strcpy(d, "doze");
      } break;
      case 3: {
        strcpy(d, "treze");
      } break;
      case 4: {
        strcpy(d, "catorze");
      } break;
      case 5: {
        strcpy(d, "quince");
      } break;
      case 6: {
        strcpy(d, "dezesseis");
      } break;
      case 7: {
        strcpy(d, "dezessete");
      } break;
      case 8: {
        strcpy(d, "dezoito");
      } break;
      case 9: {
        strcpy(d, "dezenove");
      } break;
      }
    }
  } break;
  case 2: {
    strcpy(d, "vinte");
  } break;
  case 3: {
    strcpy(d, "trinta");
  } break;
  case 4: {
    strcpy(d, "quarenta");
  } break;
  case 5: {
    strcpy(d, "cinquenta");
  } break;
  case 6: {
    strcpy(d, "sessenta");
  } break;
  case 7: {
    strcpy(d, "setenta");
  } break;
  case 8: {
    strcpy(d, "oitenta");
  } break;
  case 9: {
    strcpy(d, "noventa");
  }
  }

  if (dezena != 1)
    switch (unidade) {
    case 1: {
      if (ver == 2 && dezena > 1 || centena > 0)
        strcpy(u, "uma");
      if (ver != 2) {
        if (ver == 1)
          strcpy(u, "um");
        if (ver == 3)
          strcpy(u, "uma");
      }
    } break;
    case 2: {
      if (ver == 1)
        strcpy(u, "dois");
      if (ver != 1)
        strcpy(u, "duas");
    } break;
    case 3: {
      strcpy(u, "três");
    } break;
    case 4: {
      strcpy(u, "quatro");
    } break;
    case 5: {
      strcpy(u, "cinco");
    } break;
    case 6: {
      strcpy(u, "seis");
    } break;
    case 7: {
      strcpy(u, "sete");
    } break;
    case 8: {
      strcpy(u, "oito");
    } break;
    case 9: {
      strcpy(u, "nove");
    }
    }

  // verificar se tem e

  if (centena != 0) {
    if (dezena > 0 || unidade > 0) {
      strcat(c, " e ");
    }
  }

  if (dezena != 1) {
    if (unidade > 0 && dezena > 1) {
      strcat(d, " e ");
    }
  }

  // verificar milhao e mil
  if (ver == 1) {
    if (centena == 0 && dezena == 0 && unidade == 1)
      strcat(u, " milhão ");
    if (centena > 0 || dezena > 0 || unidade > 1)
      strcat(u, " milhões ");
  }

  if (ver == 2) {
    if (numero == 1) {
      strcat(u, "mil ");
    } else {
      strcat(u, " mil ");
    }
  }

  strcpy(txt, "");
  strcat(txt, c);
  strcat(txt, d);
  strcat(txt, u);
  strcat(ext, txt);
}

void ORD_M(int numero, char *ext, int ver) {
  int centena = 0, dezena = 0, unidade = 0;
  char c[1000], d[1000], u[1000], txt[1000];

  strcpy(c, "");
  strcpy(d, "");
  strcpy(u, "");

  centena = (int)numero / 100;
  numero = (int)numero % 100;
  dezena = (int)numero / 10;
  unidade = (int)numero % 10;

  switch (centena) {
  case 1: {
    if (ver != 3) {
      if (dezena > 0 || unidade > 0) {
        strcpy(c, "cento ");
      } else {
        strcpy(c, "cem ");
      }
    } else {
      strcpy(c, "centésimo ");
    }
  } break;
  case 2: {
    strcpy(c, "cu ");
    if (ver == 3)
      strcpy(c, "ducentésimo ");
  } break;
  case 3: {
    strcpy(c, "trezentos ");
    if (ver == 3)
      strcpy(c, "tricentésimo ");
  } break;
  case 4: {
    strcpy(c, "quatrocentos ");
    if (ver == 3)
      strcpy(c, "quadrigentésimo ");
  } break;
  case 5: {
    strcpy(c, "quinhentos ");
    if (ver == 3)
      strcpy(c, "quingentésimo ");
  } break;
  case 6: {
    strcpy(c, "seiscentos ");
    if (ver == 3)
      strcpy(c, "seiscentésimo ");
  } break;
  case 7: {
    strcpy(c, "setecentos ");
    if (ver == 3)
      strcpy(c, "septigentésimo ");
  } break;
  case 8: {
    strcpy(c, "oitocentos ");
    if (ver == 3)
      strcpy(c, "octigentésimo ");
  } break;
  case 9: {
    strcpy(c, "novecentos ");
    if (ver == 3)
      strcpy(c, "nongentésimo ");
  }
  }

  switch (dezena) {
  case 1: {
    if (ver != 3) {
      if (unidade == 0) {
        strcpy(d, "dez ");
      } else {
        switch (unidade) {
        case 1: {
          strcpy(d, "onze ");
        } break;
        case 2: {
          strcpy(d, "doze ");
        } break;
        case 3: {
          strcpy(d, "treze ");
        } break;
        case 4: {
          strcpy(d, "catorze ");
        } break;
        case 5: {
          strcpy(d, "quince ");
        } break;
        case 6: {
          strcpy(d, "dezesseis ");
        } break;
        case 7: {
          strcpy(d, "dezessete ");
        } break;
        case 8: {
          strcpy(d, "dezoito ");
        } break;
        case 9: {
          strcpy(d, "dezenove ");
        } break;
        }
      }
    }
    if (ver == 3)
      strcpy(d, "décimo ");
  } break;
  case 2: {
    strcpy(d, "vinte ");
    if (ver == 3)
      strcpy(d, "vigésimo ");
  } break;
  case 3: {
    strcpy(d, "trinta ");
    if (ver == 3)
      strcpy(d, "trigésimo ");
  } break;
  case 4: {
    strcpy(d, "quarenta ");
    if (ver == 3)
      strcpy(d, "quadragésimo ");
  } break;
  case 5: {
    strcpy(d, "cinquenta ");
    if (ver == 3)
      strcpy(d, "quinquagésimo ");
  } break;
  case 6: {
    strcpy(d, "sessenta ");
    if (ver == 3)
      strcpy(d, "sexagésimo ");
  } break;
  case 7: {
    strcpy(d, "setenta ");
    if (ver == 3)
      strcpy(d, "septuagésimo ");
  } break;
  case 8: {
    strcpy(d, "oitenta ");
    if (ver == 3)
      strcpy(d, "octogésimo ");
  } break;
  case 9: {
    strcpy(d, "noventa ");
    if (ver == 3)
      strcpy(d, "nonagésimo ");
  }
  }

  switch (unidade) {
  case 1: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "um ");
    if (ver == 3)
      strcpy(u, "primeiro ");
  } break;
  case 2: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "dois ");
    if (ver == 3)
      strcpy(u, "segundo ");
  } break;
  case 3: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "tres ");
    if (ver == 3)
      strcpy(u, "terceiro ");
  } break;
  case 4: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "quatro ");
    if (ver == 3)
      strcpy(u, "quarto ");
  } break;
  case 5: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "cinco ");
    if (ver == 3)
      strcpy(u, "quinto ");
  } break;
  case 6: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "seis ");
    if (ver == 3)
      strcpy(u, "sexto ");
  } break;
  case 7: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "sete ");
    if (ver == 3)
      strcpy(u, "setimo ");
  } break;
  case 8: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "oito ");
    if (ver == 3)
      strcpy(u, "oitavo ");
  } break;
  case 9: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "nove ");
    if (ver == 3)
      strcpy(u, "nono ");
  }
  }

  // verificar se tem e
  if (ver != 3) {
    if (centena != 0) {
      if (dezena > 0 || unidade > 0) {
        strcat(c, "e ");
      }
    }

    if (dezena != 1) {
      if (unidade > 0 && dezena > 1) {
        strcat(d, "e ");
      }
    }
  }
  // verificar milhao e mil
  if (ver == 1) {
    if (centena == 0 && dezena == 0 && unidade == 1)
      strcat(u, "milionésimo ");
    if (centena > 0 || dezena > 0 || unidade > 1)
      strcat(u, "milionésimos ");
  }

  if (ver == 2) {
    if (numero == 1) {
      strcat(u, "milésimo ");
    } else {
      strcat(u, "milésimos ");
    }
  }

  strcpy(txt, "");
  strcat(txt, c);
  strcat(txt, d);
  strcat(txt, u);
  strcat(ext, txt);
}

void ORD_F(int numero, char *ext, int ver) {
  int centena = 0, dezena = 0, unidade = 0;
  char c[1000], d[1000], u[1000], txt[1000];

  strcpy(c, "");
  strcpy(d, "");
  strcpy(u, "");

  centena = (int)numero / 100;
  numero = (int)numero % 100;
  dezena = (int)numero / 10;
  unidade = (int)numero % 10;

  switch (centena) {
  case 1: {
    if (ver != 3) {
      if (dezena > 0 || unidade > 0) {
        strcpy(c, "cento ");
      } else {
        strcpy(c, "cem ");
      }
    } else {
      strcpy(c, "centésima ");
    }
  } break;
  case 2: {
    strcpy(c, "duzentos ");
    if (ver == 3)
      strcpy(c, "ducentésima ");
  } break;
  case 3: {
    strcpy(c, "trezentos ");
    if (ver == 3)
      strcpy(c, "tricentésima ");
  } break;
  case 4: {
    strcpy(c, "quatrocentos ");
    if (ver == 3)
      strcpy(c, "quadrigentésima ");
  } break;
  case 5: {
    strcpy(c, "quinhentos ");
    if (ver == 3)
      strcpy(c, "quingentésima ");
  } break;
  case 6: {
    strcpy(c, "seiscentos ");
    if (ver == 3)
      strcpy(c, "seiscentésima ");
  } break;
  case 7: {
    strcpy(c, "setecentos ");
    if (ver == 3)
      strcpy(c, "septigentésima ");
  } break;
  case 8: {
    strcpy(c, "oitocentos ");
    if (ver == 3)
      strcpy(c, "octigentésimo ");
  } break;
  case 9: {
    strcpy(c, "novecentos ");
    if (ver == 3)
      strcpy(c, "nongentésima ");
  }
  }

  switch (dezena) {
  case 1: {
    if (ver != 3) {
      if (unidade == 0) {
        strcpy(d, "dez");
      } else {
        switch (unidade) {
        case 1: {
          strcpy(d, "onze ");
        } break;
        case 2: {
          strcpy(d, "doze ");
        } break;
        case 3: {
          strcpy(d, "treze ");
        } break;
        case 4: {
          strcpy(d, "catorze ");
        } break;
        case 5: {
          strcpy(d, "quince ");
        } break;
        case 6: {
          strcpy(d, "dezesseis ");
        } break;
        case 7: {
          strcpy(d, "dezessete ");
        } break;
        case 8: {
          strcpy(d, "dezoito ");
        } break;
        case 9: {
          strcpy(d, "dezenove ");
        } break;
        }
      }
    }
    if (ver == 3)
      strcpy(d, "décima ");
  } break;
  case 2: {
    strcpy(d, "vinte ");
    if (ver == 3)
      strcpy(d, "vigésima ");
  } break;
  case 3: {
    strcpy(d, "trinta ");
    if (ver == 3)
      strcpy(d, "trigésima ");
  } break;
  case 4: {
    strcpy(d, "quarenta ");
    if (ver == 3)
      strcpy(d, "quadragésima ");
  } break;
  case 5: {
    strcpy(d, "cinquenta ");
    if (ver == 3)
      strcpy(d, "quinquagésima ");
  } break;
  case 6: {
    strcpy(d, "sessenta ");
    if (ver == 3)
      strcpy(d, "sexagésima ");
  } break;
  case 7: {
    strcpy(d, "setenta ");
    if (ver == 3)
      strcpy(d, "septuagésima ");
  } break;
  case 8: {
    strcpy(d, "oitenta ");
    if (ver == 3)
      strcpy(d, "octogésima ");
  } break;
  case 9: {
    strcpy(d, "noventa ");
    if (ver == 3)
      strcpy(d, "nonagésima ");
  }
  }

  switch (unidade) {
  case 1: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "uma ");
    if (ver == 3)
      strcpy(u, "primeira ");
  } break;
  case 2: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "dois ");
    if (ver == 3)
      strcpy(u, "segunda ");
  } break;
  case 3: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "tres ");
    if (ver == 3)
      strcpy(u, "terceira ");
  } break;
  case 4: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "quatro ");
    if (ver == 3)
      strcpy(u, "quarta ");
  } break;
  case 5: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "cinco ");
    if (ver == 3)
      strcpy(u, "quinta ");
  } break;
  case 6: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "seis ");
    if (ver == 3)
      strcpy(u, "sexta ");
  } break;
  case 7: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "sete ");
    if (ver == 3)
      strcpy(u, "setima ");
  } break;
  case 8: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "oito ");
    if (ver == 3)
      strcpy(u, "oitava ");
  } break;
  case 9: {
    if (ver != 3 && dezena != 1)
      strcpy(u, "nove ");
    if (ver == 3)
      strcpy(u, "nona ");
  }
  }

  // verificar se tem e
  if (ver != 3) {
    if (centena != 0) {
      if (dezena > 0 || unidade > 0) {
        strcat(c, "e ");
      }
    }

    if (dezena != 1) {
      if (unidade > 0 && dezena > 1) {
        strcat(d, "e ");
      }
    }
  }
  // verificar milhao e mil
  if (ver == 1) {
    if (centena == 0 && dezena == 0 && unidade == 1)
      strcat(u, "milionésima ");
    if (centena > 0 || dezena > 0 || unidade > 1)
      strcat(u, "milionésimas ");
  }

  if (ver == 2) {
    if (numero == 1) {
      strcat(u, "milésima ");
    } else {
      strcat(u, "milésimas ");
    }
  }

  strcpy(txt, "");
  strcat(txt, c);
  strcat(txt, d);
  strcat(txt, u);
  strcat(ext, txt);
}