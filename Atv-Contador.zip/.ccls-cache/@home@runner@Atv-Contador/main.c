#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main() {
  char palavra[100];
  int tamanho = 0;
  int vogal = 0;
  int conso = 0;
  int espac = 0;
  int cont = 0;
  int acento = 0;
  int numero = 0;
  printf("\nDigite uma palavra/frase: ");
  gets(palavra);
  tamanho = strlen(palavra);
  for (cont = 0; cont < tamanho; cont++) {
    switch (palavra[cont]) {
    case 'a':
    case 'A':
    case 'e':
    case 'E':
    case 'i':
    case 'I':
    case 'o':
    case 'O':
    case 'u':
    case 'U': {
      vogal++;
    } break;
    case ' ': {
      espac++;
    } break;
    case 'b':
    case 'B':
    case 'c':
    case 'C':
    case 'd':
    case 'D':
    case 'f':
    case 'F':
    case 'g':
    case 'G':
    case 'h':
    case 'H':
    case 'j':
    case 'J':
    case 'k':
    case 'K':
    case 'l':
    case 'L':
    case 'm':
    case 'M':
    case 'n':
    case 'N':
    case 'p':
    case 'P':
    case 'q':
    case 'Q':
    case 'r':
    case 'R':
    case 's':
    case 'S':
    case 't':
    case 'T':
    case 'v':
    case 'V':
    case 'w':
    case 'W':
    case 'x':
    case 'X':
    case 'y':
    case 'Y':
    case 'z':
    case 'Z': {
      conso++;
    } break;
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
    case '9': {
      numero++;
    } break;
    default: {
      acento++;
      vogal++;
    }
    }
  }
  acento /= 2;
  printf("\nA palavra/frase digitada foi: %s", palavra);
  printf("\nA quantidade de caracteres é: %i", tamanho);
  printf("\nA quantidade de vogais é: %i", vogal - acento);
  printf("\nA quantidade de consoantes é: %i", conso);
  printf("\nA quantidade de espaços é: %i", espac);
  printf("\nA quantidade de acentos é: %i", acento);
  printf("\nA quantidade de números é: %i", numero);
  printf("\n\nFim...");
}