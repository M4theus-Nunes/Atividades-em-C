#include <stdio.h>
#include <stdlib.h>
#include <string.h>
main() {
  char palavra[100];
  int tamanho = 0;
  int vogal = 0;
  int conso = 0;
  int espac = 0;
  int cont = 0;

  printf("Digite uma palavra: ");
  gets(palavra);
  tamanho = strlen(palavra);
  for (cont = 0; cont < tamanho; cont++) {
    switch (palavra[cont]) {
    case 'a':
    case 'A':
    case 'e':
    case 'E':
    case 'i':
    case 'I':
    case 'o':
    case 'O':
    case 'u':
    case 'U': {
      vogal++;
    } break;
    case ' ': {
      espac++;
    } break;
    default: {
      conso++;
    }
    }
  }
  printf("\nA palavra digitada foi: %s", palavra);
  printf("\nA quantidade de caracteres é: %i", tamanho);
  printf("\nA quantidade de vogais é: %i", vogal);
  printf("\nA quantidade de consoantes é: %i", conso);
  printf("\nA quantidade de espaços é: %i", espac);
  printf("\n\nFim...");
}