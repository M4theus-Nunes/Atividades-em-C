#include <stdlib.h>
#include <stdio.h>
#include <string.h>
int main (){
  char palavra [100], palindromo [100];
  int temp, i, j = 0;
  printf ("\nDigite um numero ou palavra: ");
  gets (palavra);
  temp = strlen (palavra);
  for (i = temp - 1; i >= 0; i-- ){
  palindromo [j] = palavra [i];
  j++;
  
  }
  temp = strcmp (palavra, palindromo);
  if (temp == 0) {
    printf ("\nÉ palíndromo\n");
     printf ("\nO numero ou palavra escrita inversamente fica: %s\n", palindromo);
  }else {
 printf ("\nO numero ou palavra escrita inversamente fica: %s\n", palindromo);
    printf ("\nNão é um palíndromo\n");
  }
}